package practica1;

import java.net.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.*;

public class Client {

	public static final String HOST = "localhost";
	public static final int PUERTO = 8080;
	private static String request;

	Socket socket;
	BufferedReader entrada;
	PrintStream salida;

	public Client() {
		try {
			this.socket = new Socket(HOST, PUERTO);
			this.salida = new PrintStream(socket.getOutputStream());
			this.entrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public Socket getSocket() {
		return socket;
	}

	public BufferedReader getEntrada() {
		return entrada;
	}

	public PrintStream getSalida() {
		return salida;
	}

	public void enviarPeticion(PrintStream salida) {
		try {
			request = "GET / HTTP/1.1 \r\n\r\n";
			salida.println(request);
		} catch (Exception e) {
			System.out.println("Cliente: No se ha podido enviar la solicitud");
		}
	}
	
	public void imprimirRespuesta(BufferedReader entrada) {
		
		StringBuilder cadenaCompleta = new StringBuilder();
		Pattern patron = Pattern.compile("Content-Length: (\\d+)");
		int bytes=0;

		String linea;		
		try {
			while((linea = entrada.readLine()).isEmpty() != true) {
				cadenaCompleta.append(linea+"\r\n");
			
				Matcher m = patron.matcher(linea);
				if(m.matches()) {
					bytes = Integer.parseInt(m.group(1));
				}
			}
			cadenaCompleta.append("\r\n");
			if(bytes!=0) {
				char[] datos = new char[bytes];
				entrada.read(datos, 0, bytes);
				cadenaCompleta.append(datos);
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println(cadenaCompleta.toString());
	}

	public static void main(String[] args) {
		
			Client cliente = new Client();	
			cliente.enviarPeticion(cliente.getSalida());
			cliente.imprimirRespuesta(cliente.getEntrada());		
	}

}
