 package practica1;

import java.net.*;
import java.io.*;

public class Server {
	
	public static final String HOST = "localhost";
	public static final int PUERTO = 8080;	
	
	Socket socketCliente;
	ServerSocket socket;
	
	public Server() {
			try {
				this.socketCliente = null;	
				this.socket = new ServerSocket(PUERTO);
			} catch (IOException e) {
				e.printStackTrace();
			}
	}
	

	public static void main(String[] args) {
		Server servidor = new Server();
		System.out.println("Servidor iniciado. Escuchando peticiones en el puerto 8080.");
		
		while(true) {
			try {
				servidor.socketCliente = servidor.socket.accept();
				new ManejadorPeticiones(servidor.socketCliente).start();
			} catch (Exception e) {
				System.out.println("Servidor: Error al aceptar la conexión de sockets o al lanzar el hilo manejador.");
			}
		}
	}
}
