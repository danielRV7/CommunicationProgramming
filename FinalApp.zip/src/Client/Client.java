package Client;

import java.net.*;

public class Client {

    protected DatagramSocket socketA;
    protected DatagramSocket socketB;
    protected DatagramPacket paqueteRecibir;
    protected String mensajeRecibido;

    protected int puertoA;
    protected int puertoB;
    protected InetAddress direccionServerA;
    protected InetAddress direccionServerB;

    protected String[] mensajesA = new String[3];
    protected String[] mensajesB = new String[3];

    public Client() {
        try {
            this.puertoA = -1;
            this.puertoB = -1;
            this.socketA = new DatagramSocket(9090);
            this.socketB = new DatagramSocket(9091);

            for(int i=0; i<3; i++){
                mensajesA[i] = "Esperando mensaje.";
                mensajesB[i] = "Esperando mensaje.";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Client cliente = new Client();
        System.out.println("Bienvenido al centro de meteorologia.\r\n");

        HiloRecepcionMeteo recepcion = new HiloRecepcionMeteo(cliente);
        recepcion.start();

        HiloHTTP http = new HiloHTTP(cliente);
        HiloHTTPS https = new HiloHTTPS(cliente);
        HiloSMTP smtp = new HiloSMTP(cliente);

        http.start();
        https.start();
        smtp.run();
    }
}
