package Client;

import java.net.*;
import java.io.*;

public class HiloHTTP extends Thread{

    public static final int PUERTO = 80;
    private Socket socketCliente;
    private ServerSocket socket;
    private Client cliente;

    public HiloHTTP(Client cliente) {
        try {
            this.socketCliente = null;
            this.socket = new ServerSocket(PUERTO);
            this.cliente = cliente;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void run(){
        System.out.println("HTTP --> Escuchando peticiones en 'http://localhost' o en 'localhost:80'\r\n");
        boolean running = true;
        while(running) {
            try {
                socketCliente = socket.accept();
                new ImpresionNavegador(socketCliente,cliente).start();
            } catch (Exception e) {
                System.out.println("Servidor: Error al aceptar la conexión de sockets o al lanzar el hilo manejador.");
            }
        }
    }
}
