package Client;

import java.net.*;
import java.io.FileInputStream;
import java.security.KeyStore;
import javax.net.ServerSocketFactory;
import javax.net.ssl.*;

public class HiloHTTPS extends Thread {

    private Client cliente;
    public static final int PUERTO = 443;
    private Socket socketCliente;
    private SSLServerSocket socket;

    public HiloHTTPS(Client cliente) {
        this.cliente = cliente;

        try {
            this.socketCliente = null;
            KeyStore ks = KeyStore.getInstance("JKS");
            String keystore = "certs/serverkeystore";
            char[] keystorepwd = "hola".toCharArray();
            ks.load(new FileInputStream(keystore),keystorepwd);

            KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
            kmf.init(ks, keystorepwd);

            TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
            tmf.init(ks);

            SSLContext sslctx = SSLContext.getInstance("TLS");
            sslctx.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

            ServerSocketFactory ssf = sslctx.getServerSocketFactory();
            socket = (SSLServerSocket)ssf.createServerSocket(PUERTO);
            socket.setNeedClientAuth(true);
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public void run(){
        System.out.println("HTTPS --> Escuchando peticiones en 'https://localhost' o en 'localhost:443'\r\n");

        boolean running = true;
        while(running){
            try {
                socketCliente = socket.accept();
                new ImpresionNavegador(socketCliente, cliente).start();
            } catch (Exception e) {
                System.out.println("Servidor: Error al aceptar la conexión de sockets o al lanzar el hilo manejador.");
            }
        }
    }
}
