package Client;

import Parsers.*;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.SocketTimeoutException;
import Mensajes.Datos;

public class HiloRecepcionMeteo extends Thread{

    private Client cliente;
    private byte[] bufferEntrada = new byte[65535];
    private boolean running = true;
    private boolean servidorTurno = true;
    private ParserJSON parserJSON = new ParserJSON();
    private ParserXML parserXML = new ParserXML();

    public HiloRecepcionMeteo(Client cliente) {
        this.cliente = cliente;
    }

    public synchronized void recibirInformacion() {
        Datos datos = null;
        char servidor='A';
        String formato="";
        try {
            cliente.paqueteRecibir = new DatagramPacket(bufferEntrada , bufferEntrada.length);
            cliente.socketA.setSoTimeout(100);
            cliente.socketB.setSoTimeout(100);
            try{
                if(servidorTurno) {
                    servidor = 'A';
                    cliente.socketA.receive(cliente.paqueteRecibir);
                    cliente.puertoA = cliente.paqueteRecibir.getPort();
                    cliente.direccionServerA = cliente.paqueteRecibir.getAddress();
                }
                else{
                    servidor = 'B';
                    cliente.socketB.receive(cliente.paqueteRecibir);
                    cliente.puertoB = cliente.paqueteRecibir.getPort();
                    cliente.direccionServerB = cliente.paqueteRecibir.getAddress();
                }
                servidorTurno = !servidorTurno;

                cliente.mensajeRecibido = new String(cliente.paqueteRecibir.getData() , 0 , cliente.paqueteRecibir.getLength());
                String partes[] = cliente.mensajeRecibido.split("=",2);
                formato = partes[0];
                String mensaje = partes[1];

                if(formato.equals("JSON")){
                    datos = parserJSON.deserializar(mensaje);
                }
                else{
                    datos = parserXML.deserializar(mensaje);
                }

            }catch(SocketTimeoutException e){
                servidorTurno = !servidorTurno;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(datos!=null) {
            String texto = datos.imprimir(formato , servidor);
            addMensaje(texto,servidor);
        }
    }

    private synchronized void addMensaje(String texto , char servidor) {

        if(!cliente.mensajesA[2].equals("Esperando mensaje.")){
            cliente.mensajesA[0] = cliente.mensajesA[1];
            cliente.mensajesA[1] = cliente.mensajesA[2];
            cliente.mensajesA[2]="Esperando mensaje.";
        }
        if(!cliente.mensajesB[2].equals("Esperando mensaje.")){
            cliente.mensajesB[0] = cliente.mensajesB[1];
            cliente.mensajesB[1] = cliente.mensajesB[2];
            cliente.mensajesB[2]="Esperando mensaje.";
        }

        if(servidor=='A'){
            int i = 0;
            while(!cliente.mensajesA[i].equals("Esperando mensaje.")){
                i++;
            }
            cliente.mensajesA[i]=texto;
        }
        else{
            int x=0;
            while(!cliente.mensajesB[x].equals("Esperando mensaje.")){
                x++;
            }
            cliente.mensajesB[x]=texto;
        }
    }

    @Override
    public void run() {
        while(running){
            recibirInformacion();
        }
    }
}
