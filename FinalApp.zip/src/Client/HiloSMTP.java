package Client;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.Folder;
import javax.mail.Store;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


public class HiloSMTP {

    private Client cliente;
    private boolean recibido;

    public HiloSMTP(Client cliente) {
        this.cliente = cliente;
        this.recibido = false;
    }

    public void comprobarCorreo(){

        Properties prop = new Properties();
        prop.setProperty("mail.pop3.starttls.enable", "false");
        prop.setProperty("mail.pop3.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        prop.setProperty("mail.pop3.socketFactory.fallback", "false");
        prop.setProperty("mail.pop3.port", "995");
        prop.setProperty("mail.pop3.socketFactory.port", "995");
        Session sesion = Session.getInstance(prop);

        try {
            Store store = sesion.getStore("pop3");
            store.connect("pop.gmail.com", "RecibirPPC@gmail.com", "practicasppc");
            Folder folder = store.getFolder("INBOX");
            folder.open(Folder.READ_ONLY);

            Message[] mensajes = folder.getMessages();

            for (int i = 0; i < mensajes.length; i++){
                if(mensajes[i].getSubject().equals("Solicitud")){
                    recibido = true;
                    mensajes[i].getContent();
                }
            }

            folder.close(false);
            store.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public void responderCorreo(){

        try {
            Properties props = new Properties();
            props.setProperty("mail.smtp.host", "smtp.gmail.com");
            props.setProperty("mail.smtp.starttls.enable", "true");
            props.setProperty("mail.smtp.port", "587");
            props.setProperty("mail.smtp.user", "EnvioPPC@gmail.com");
            props.setProperty("mail.smtp.auth", "true");

            Session session = Session.getDefaultInstance(props);

            MimeMessage message = new MimeMessage(session);

            message.setFrom(new InternetAddress("EnvioPPC@gmail.com"));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress("RecibirPPC@gmail.com"));
            message.setSubject("Ultimas mediciones meteorologicas.");

            String[] mensajesA = new String[3];
            String[] mensajesB = new String[3];

            for(int i=0; i<3; i++){
                mensajesA[i] = cliente.mensajesA[i];
                mensajesB[i] = cliente.mensajesB[i];
            }
            String respuesta =
                    "\t\tMensajes del servidor A: " + "\r\n\r\n"
                    + mensajesA[0] + "\r\n"
                    + mensajesA[1] + "\r\n"
                    + mensajesA[2] + "\r\n"
                    + "\t\tMensajes del servidor B: " + "\r\n\r\n"
                    + mensajesB[0] + "\r\n"
                    + mensajesB[1] + "\r\n"
                    + mensajesB[2] + "\r\n";

            message.setText(respuesta);

            Transport t = session.getTransport("smtp");
            t.connect("EnvioPPC@gmail.com", "practicasppc");
            t.sendMessage(message, message.getAllRecipients());
            t.close();

        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    public void run() {
        System.out.println("Correo --> Envíe un correo con el asunto 'Solicitud' a la dirección 'RecibirPPC@gmail.com'\r\n");
        while(true){
            comprobarCorreo();
            if(recibido){
                responderCorreo();
                recibido = false;
            }
            else{
                try {
                    Thread.sleep(10000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
