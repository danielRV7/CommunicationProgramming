package Client;

import java.net.*;
import java.io.*;

public class ImpresionNavegador extends Thread {

    private Socket socket;
    private PrintStream salida;
    private Client cliente;

    public ImpresionNavegador(Socket socket, Client cliente) {
        this.socket = socket;
        this.cliente = cliente;
    }

    public void imprimirMeteorologia(PrintStream salida) {
        String[] mensajesA = new String[3];
        String[] mensajesB = new String[3];

        for(int i=0; i<3; i++){
            mensajesA[i] = cliente.mensajesA[i];
            mensajesB[i] = cliente.mensajesB[i];
        }

        String welcome = "Bienvenido al servicio de meteorologia ";
        String respuesta = welcome + "\r\n\r\n"
                        + "\t\tMensajes del servidor A: " + "\r\n\r\n"
                        + mensajesA[0] + "\r\n"
                        + mensajesA[1] + "\r\n"
                        + mensajesA[2] + "\r\n"
                        + "\t\tMensajes del servidor B: " + "\r\n\r\n"
                        + mensajesB[0] + "\r\n"
                        + mensajesB[1] + "\r\n"
                        + mensajesB[2] + "\r\n";

        salida.println(respuesta);
        salida.close();
    }

    public void run() {
        try {
            salida = new PrintStream(socket.getOutputStream());
            imprimirMeteorologia(salida);
        } catch (Exception e) {
            System.out.println("Manejador: Error en la ejecución del Thread");
        }
    }

}
