package Parsers;
import Mensajes.Datos;

public interface Parser {

    String serializar(Datos datos);
    String serializarControl(String comando);
    Datos deserializar(String json);
    String deserializarControl(String json);
}
