package Parsers;

import Mensajes.Datos;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import com.google.gson.Gson;

public class ParserJSON implements Parser{

    Gson gson = new Gson();

    @Override
    public String serializar(Datos datos) {

        String json = gson.toJson(datos);
        try {
            String aux = json + System.getProperty("line.separator");
            Files.write(Paths.get("JSON/MensajesDistribucion.json") , aux.getBytes() , StandardOpenOption.CREATE , StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.err.println("ERROR EN EL FICHERO: " + e.getMessage());
        }
        return json;
    }

    @Override
    public Datos deserializar(String json) {
        return gson.fromJson(json, Datos.class);
    }

    @Override
    public String serializarControl(String comando) {

        String json = gson.toJson(comando);
        try {
            Files.write(Paths.get("JSON/MensajesControl.json"), json.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        }catch (IOException e) {
            System.err.println("ERROR EN EL FICHERO: " + e.getMessage());
        }
        return json;
    }

    @Override
    public String deserializarControl(String json) {
        return gson.fromJson(json, String.class);
    }
}
