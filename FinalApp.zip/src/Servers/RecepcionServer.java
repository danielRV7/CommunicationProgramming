package Servers;

import Parsers.ParserJSON;
import Parsers.ParserXML;
import Mensajes.*;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;

public class RecepcionServer extends Thread {

    private Server server;
    protected byte[] bufferEntrada = new byte[65535];
    private DatagramPacket paqueteRecibido;
    private DatagramPacket paqueteEnvio;
    private ParserJSON parserJSON = new ParserJSON();
    private ParserXML parserXML = new ParserXML();
    private String mensajeJson;
    private String mensajeXML;
    private boolean json;

    public RecepcionServer(Server server){
        this.server = server;
        this.json = true;
    }

    public void comprobarRecepcion() {
        boolean running = true;
        String formato;
        String control;
        while(running){
                    try {
                        paqueteRecibido = new DatagramPacket(bufferEntrada , bufferEntrada.length);
                        server.socketServer.receive(paqueteRecibido);
                        String mensajeRecibido = new String(paqueteRecibido.getData() , 0 , paqueteRecibido.getLength());
                        String partes[] = mensajeRecibido.split("=",2);
                        formato = partes[0];
                        String mensaje = partes[1];
                        if(formato.equals("JSON")){
                            mensaje = mensaje.substring(1,mensaje.length()-1);
                            control = parserJSON.deserializarControl(mensaje);
                        }
                        else{
                            control = parserXML.deserializarControl(mensaje);
                        }
                        if(control!=null) {
                            System.out.println("COMANDO RECIBIDO! " + control + "\t Dirección: " + paqueteRecibido.getAddress());

                            if(server.servidor=='A'){
                                tratarMensaje(control , paqueteRecibido.getAddress(), 9090);
                            }
                            else{
                                tratarMensaje(control , paqueteRecibido.getAddress(), 9091);
                            }
                        }

                        if(paqueteEnvio!=null) {
                            server.socketServer.send(paqueteEnvio);
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
            }
    }
    // Método general de construccion del mensaje de respuesta.

    public void construirMensaje(InetAddress direccionIP, int puerto, char server, String palabra){

        MensajeDistribucion mensaje = new MensajeDistribucion(server, palabra);

        if(server=='A'){
            Datos datos = new Datos();
            datos.setLluvia(mensaje.getLluvia());
            datos.setViento(mensaje.getViento());
            datos.setPresion(mensaje.getPresion());
            datos.setUnidadLluvia(mensaje.getUnidadLluvia());
            datos.setUnidadViento(mensaje.getUnidadViento());
            datos.setUnidadPresion(mensaje.getUnidadPresion());
            if(this.json){
                String json = parserJSON.serializar(datos);
                mensajeJson = "JSON" + "=" + json;
                byte[] array = mensajeJson.getBytes();
                paqueteEnvio = new DatagramPacket(array , array.length , direccionIP , puerto);
            }
            else{
                String xml = parserXML.serializar(datos);
                mensajeXML = "XML" + "=" + xml;
                byte[] array = mensajeXML.getBytes();
                paqueteEnvio = new DatagramPacket(array , array.length , direccionIP , puerto);
            }
        }
        else{
            Datos datos = new Datos();
            datos.setTemperatura(mensaje.getTemperatura());
            datos.setHumedad(mensaje.getHumedad());
            datos.setRadiactividad(mensaje.getRadiactividad());
            datos.setUnidadTemperatura(mensaje.getUnidadTemperatura());
            datos.setUnidadHumedad(mensaje.getUnidadHumedad());
            datos.setUnidadRadiactividad(mensaje.getUnidadRadiactividad());
            if(this.json){
                String json = parserJSON.serializar(datos);
                mensajeJson = "JSON" + "=" + json;
                byte[] array = mensajeJson.getBytes();
                paqueteEnvio = new DatagramPacket(array , array.length , direccionIP , puerto);
            }
            else{
                String xml = parserXML.serializar(datos);
                mensajeXML = "XML" + "=" + xml;
                byte[] array = mensajeXML.getBytes();
                paqueteEnvio = new DatagramPacket(array , array.length , direccionIP , puerto);
            }
        }
    }
    // Método que trata el comando recibido del cliente.

    public void tratarMensaje(String mensajeRecibido , InetAddress direccionIP , int puerto) {
        if(server.servidor=='A') {
            switch (mensajeRecibido) {
                case "CHRAIN":
                    construirMensaje(direccionIP, puerto, 'A', "lluvia");
                    break;
                case "CHWIND":
                    construirMensaje(direccionIP, puerto, 'A', "viento");
                    break;
                case "CHPRESS":
                    construirMensaje(direccionIP, puerto, 'A', "presion");
                    break;
                case "XML":
                    this.json = false;
                    break;
                case "JSON":
                    this.json = true;
                    break;
                default:
                    paqueteEnvio = null;
            }
        }
        else if(server.servidor=='B'){
            switch(mensajeRecibido){
                case "CHTEMP":
                    construirMensaje(direccionIP, puerto, 'B', "temperatura");
                    break;
                case "CHHUM":
                    construirMensaje(direccionIP, puerto, 'B', "humedad");
                    break;
                case "CHRAD":
                    construirMensaje(direccionIP, puerto, 'B', "radiactividad");
                    break;
                case "XML":
                    this.json = false;
                    break;
                case "JSON":
                    this.json = true;
                    break;
                default:
                    paqueteEnvio = null;
            }
        }
    }

    public boolean isJson() {
        return json;
    }

    @Override
    public void run() {
        comprobarRecepcion();
    }
}
