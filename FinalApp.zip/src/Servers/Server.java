package Servers;

import java.net.*;
import java.util.Enumeration;

public class Server{

    protected DatagramSocket socketServer;
    protected DatagramPacket paqueteEnviar;
    protected char servidor;

    public static InetAddress getBroadcast() {
        Enumeration<NetworkInterface> interfaces = null;
        InetAddress broadcast = null;
        try {
            interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces.hasMoreElements()) {
                NetworkInterface networkInterface = interfaces.nextElement();
                if (networkInterface.isLoopback()) {
                    continue;
                }
                for (InterfaceAddress interfaceAddress : networkInterface.getInterfaceAddresses()) {
                    broadcast = interfaceAddress.getBroadcast();
                    if (broadcast != null) {
                        return broadcast;
                    }
                }
            }
        }catch (SocketException e){
            e.printStackTrace();
        }
        return broadcast;
    }
}


