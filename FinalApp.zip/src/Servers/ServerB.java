package Servers;

import Parsers.ParserJSON;
import Parsers.ParserXML;
import Mensajes.*;

import java.io.IOException;
import java.net.*;

public class ServerB extends Server {

    private ParserJSON parserJSON = new ParserJSON();
    private ParserXML parserXML = new ParserXML();

    public ServerB() {
        try {
            this.socketServer = new DatagramSocket();
            this.servidor = 'B';
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        ServerB server = new ServerB();
        boolean running = true;
        byte[] bytesTexto;

        RecepcionServer recepcionServer = new RecepcionServer(server);
        recepcionServer.start();
        while (running) {
            if(recepcionServer.isJson()){
                MensajeDistribucion mensaje = new MensajeDistribucion('B');
                Datos datos = new Datos();
                datos.setTemperatura(mensaje.getTemperatura());
                datos.setHumedad(mensaje.getHumedad());
                datos.setRadiactividad(mensaje.getRadiactividad());
                datos.setUnidadTemperatura(mensaje.getUnidadTemperatura());
                datos.setUnidadHumedad(mensaje.getUnidadHumedad());
                datos.setUnidadRadiactividad(mensaje.getUnidadRadiactividad());
                String json = server.parserJSON.serializar(datos);
                String mensajeJson = "JSON" + "=" + json;
                bytesTexto = mensajeJson.getBytes();
            }
            else{
                MensajeDistribucion mensaje = new MensajeDistribucion('B');
                Datos datos = new Datos();
                datos.setTemperatura(mensaje.getTemperatura());
                datos.setHumedad(mensaje.getHumedad());
                datos.setRadiactividad(mensaje.getRadiactividad());
                datos.setUnidadTemperatura(mensaje.getUnidadTemperatura());
                datos.setUnidadHumedad(mensaje.getUnidadHumedad());
                datos.setUnidadRadiactividad(mensaje.getUnidadRadiactividad());
                String xml = server.parserXML.serializar(datos);
                String mensajeXML = "XML" + "=" + xml;
                bytesTexto = mensajeXML.getBytes();
            }

            try {
                InetAddress direccionBroadcast = getBroadcast();
                if(direccionBroadcast==null){
                    direccionBroadcast = InetAddress.getByName("localhost");
                }
                server.paqueteEnviar = new DatagramPacket(bytesTexto, bytesTexto.length, direccionBroadcast, 9091);
                server.socketServer.send(server.paqueteEnviar);
                Thread.sleep(5000);
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
