package Client;

import java.net.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.*;

public class Client {

    public static void enviarPeticion(String request, PrintStream salida) {
        try {
            salida.println(request);
        } catch (Exception e) {
            System.out.println("Cliente: No se ha podido enviar la solicitud");
        }
    }

    public static void imprimirRespuesta(BufferedReader entrada) {

        StringBuilder cadenaCompleta = new StringBuilder();
        Pattern patron = Pattern.compile("Content-Length: (\\d+)");
        int bytes=0;

        String linea;
        try {
            while((linea = entrada.readLine()).isEmpty() != true) {
                cadenaCompleta.append(linea+"\r\n");

                Matcher m = patron.matcher(linea);
                if(m.matches()) {
                    bytes = Integer.parseInt(m.group(1));
                }
            }
            cadenaCompleta.append("\r\n");
            if(bytes!=0) {
                char[] datos = new char[bytes];
                entrada.read(datos, 0, bytes);
                cadenaCompleta.append(datos);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(cadenaCompleta.toString());
    }

    public static void main(String[] args) {
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
                BufferedReader protocolo = new BufferedReader(new InputStreamReader(System.in));

                System.out.println("Introduce el recurso que quieres solicitar (incluye la /):");
                String recurso = reader.readLine();

                System.out.println("Introduce el formato que deseas para tu petición.");
                System.out.println("Opciones: http - https");
                String compare = protocolo.readLine();
                String eleccion;
                Conexion conexion;

                if(compare.equals("http")){
                    eleccion = "HTTP/1.1";
                    conexion = new ConexionHTTP();
                }
                else{
                    eleccion = "HTTPS/1.1";
                    conexion = new ConexionHTTPS();
                }
                Socket socket = conexion.connect("localhost");

                PrintStream salida = new PrintStream(socket.getOutputStream());
                BufferedReader entrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                String request = "GET " + recurso + " " + eleccion + " \r\n"
                                + "Host:" + " localhost" + " \r\n"
                                + "Accept-Language: es \r\n\r\n";

                enviarPeticion(request, salida);
                imprimirRespuesta(entrada);

                salida.close();
                entrada.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }