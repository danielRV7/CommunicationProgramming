package Client;

import java.net.Socket;

public interface Conexion {
    Socket connect(String host);
}
