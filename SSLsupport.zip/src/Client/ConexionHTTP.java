package Client;

import java.io.IOException;
import java.net.Socket;

public class ConexionHTTP implements Conexion{

    @Override
    public Socket connect(String host) {
        try {
            return new Socket(host, 8080);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
