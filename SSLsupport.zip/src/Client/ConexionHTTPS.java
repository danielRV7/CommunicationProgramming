package Client;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;
import java.io.FileInputStream;
import java.net.Socket;
import java.security.KeyStore;

public class ConexionHTTPS implements Conexion{

    private final char[] keystorepwd = "hola".toCharArray();
    private final String keystore = "certs/clientkeystore";

    @Override
    public Socket connect(String host) {
        try {
            KeyStore identityKeyStore = KeyStore.getInstance("jks");
            identityKeyStore.load(new FileInputStream(keystore), keystorepwd);

            KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
            kmf.init(identityKeyStore, keystorepwd);

            TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
            tmf.init(identityKeyStore);

            SSLContext sslcntx = SSLContext.getInstance("TLS");
            sslcntx.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

            SSLSocketFactory socketFactory = sslcntx.getSocketFactory();
            return socketFactory.createSocket(host, 443);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
