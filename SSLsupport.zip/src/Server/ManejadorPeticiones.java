package Server;

import java.net.*;
import java.util.StringTokenizer;
import java.io.*;

public class ManejadorPeticiones extends Thread {

    private static String respuesta;
    private static int numCookie = 0;
    private Socket socket;

    private BufferedReader entrada;
    private PrintStream salida;

    public ManejadorPeticiones(Socket socket) {
        this.socket = socket;
        numCookie++;
    }

    public String leerPeticion(BufferedReader entrada) {

        StringBuilder cadenaCompleta = new StringBuilder();
        String linea;
        try {
            while (((linea = entrada.readLine()).isEmpty()) != true) {
                cadenaCompleta.append(linea);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cadenaCompleta.toString();
    }

    public void responderPeticion(PrintStream salida, String cadena) {
        StringTokenizer recursoToken = new StringTokenizer(cadena);
        recursoToken.nextToken();
        String recurso = recursoToken.nextToken();

        if(recurso.compareTo("/") == 0) {
            recurso = "/index.html ";
        }

        String formato;
        String compare = recursoToken.nextToken();

        if(compare.equals("HTTP/1.1")){
            formato = "HTTP/1.1";
        }
        else{
            formato = "HTTPS/1.1";
        }

        String html = "<html> <body> <p>" + " El cliente ha solicitado el recurso: " + recurso + " Set-Cookie: numCookie = " + numCookie + " </p> </body> </html>";
        int size = html.length();
        respuesta = formato + " 200 OK \r\n" + "Content-Length: " + size + "\r\nSet-Cookie: numCookie = " + numCookie + "\r\n\r\n" + html;

        salida.println(respuesta);
        salida.close();

    }

    public void run() {

        try {
            entrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            salida = new PrintStream(socket.getOutputStream());

            String cadena = leerPeticion(entrada);
            responderPeticion(salida,cadena);

        } catch (Exception e) {
            System.out.println("Manejador: Error en la ejecución del Thread");
        }
    }

}
