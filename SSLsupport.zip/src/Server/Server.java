package Server;

public class Server {

    public static void main(String[] args) {
        new ServerHTTP().start();
        new ServerHTTPS().start();
    }
}
