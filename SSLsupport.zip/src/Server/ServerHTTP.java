package Server;

import java.net.*;
import java.io.*;

public class ServerHTTP extends Thread{

    public static final int PUERTO = 8080;

    private Socket socketCliente;
    private ServerSocket socket;

    public ServerHTTP() {
        try {
            this.socketCliente = null;
            this.socket = new ServerSocket(PUERTO);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void run(){
        System.out.println("Servidor iniciado. Escuchando peticiones en el puerto 8080.");

        boolean running = true;
        while(running) {
            try {
                socketCliente = socket.accept();
                new ManejadorPeticiones(socketCliente).start();
            } catch (Exception e) {
                System.out.println("Servidor: Error al aceptar la conexión de sockets o al lanzar el hilo manejador.");
            }
        }
    }
}
