package practica2;

import java.io.IOException;
import java.net.*;
import java.util.*;

public class Client {

    protected DatagramSocket socketA;
    protected DatagramSocket socketB;
    protected DatagramPacket paqueteEnviar;
    protected DatagramPacket paqueteRecibir;

    protected int puertoA;
    protected int puertoB;
    protected InetAddress direccionServerA;
    protected InetAddress direccionServerB;

    protected String comando;
    private Scanner entradaCliente;
    protected String mensajeRecibido;


    public Client() {
        try {
            this.puertoA = -1;
            this.puertoB = -1;
            this.entradaCliente = new Scanner(System.in);
            this.socketA = new DatagramSocket(9090);
            this.socketB = new DatagramSocket(9091);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public synchronized void enviarComando(String comandoEnviar, int puertoServer, InetAddress direccionServer){
        try {
            byte[] envio = comandoEnviar.getBytes();
            paqueteEnviar = new DatagramPacket(envio , envio.length, direccionServer, puertoServer);
            socketA.send(paqueteEnviar);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void ejecucion(Client cliente){
        ImpresionCliente impresion = new ImpresionCliente(cliente);
        impresion.start();
        do{
            comando = entradaCliente.nextLine();
            if(!comando.equals("STOP")){
                if((comando.equals("CHRAIN")) || (comando.equals("CHWIND")) || (comando.equals("CHPRESS"))) {
                    if(puertoA!=-1) {
                        cliente.enviarComando(comando , puertoA , direccionServerA);
                    }
                }
                else{
                    if(puertoB!=-1){
                        cliente.enviarComando(comando, puertoB, direccionServerB);
                    }
                }
            }
        }while(!cliente.comando.equals("STOP"));
        impresion.terminar();
        try {
            impresion.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        cliente.socketA.close();
        cliente.socketB.close();
    }

    public void ayudaComandos() {
        System.out.println("----------------- Comandos generales -----------------\r\n"
                + "\tSTART: Inicia la recepción.\r\n"
                + "\tSTOP: Interrumpe la recepción.\r\n"
                + "\tHELP: Muestra la ayuda.\r\n"
                + "----------------- Comandos: Servidor A -----------------\r\n"
                + "\tCHRAIN: Cambia la unidad de medición de la lluvia.\r\n"
                + "\tCHWIND: Cambia la unidad de medición del viento.\r\n"
                + "\tCHPRESS: Cambia la unidad de medición de la presión.\r\n"
                + "----------------- Comandos: Servidor B -----------------\r\n"
                + "\tCHTEMP: Cambia la unidad de medición de la temperatura.\r\n"
                + "\tCHHUM: Cambia la unidad de medición de la humedad.\r\n"
                + "\tCHRAD: Cambia la unidad de medición de la radiactividad.\r\n"
                + "\r\n");
    }

    public static void main(String[] args) {
        Client cliente = new Client();
        cliente.ayudaComandos();
        System.out.println("NOTA: El primer comando introducido debe ser START.");
        cliente.comando = cliente.entradaCliente.nextLine();

        if (cliente.comando.equals("START")) {
            cliente.ejecucion(cliente);
        }
        else{
            do{
                System.out.println("Comando incorrecto. Introduzca START, por favor.");
                cliente.comando = cliente.entradaCliente.nextLine();
            }while(!cliente.comando.equals("START"));
            cliente.ejecucion(cliente);
        }
    }
}
