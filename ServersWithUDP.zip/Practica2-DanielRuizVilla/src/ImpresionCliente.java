package practica2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.SocketTimeoutException;

public class ImpresionCliente extends Thread{

    protected Client cliente;
    private byte[] bufferEntrada = new byte[512];
    protected boolean running = true;


    public ImpresionCliente(Client cliente) {
        this.cliente = cliente;
    }

    public synchronized void imprimirInformacion() {
        try {
            cliente.paqueteRecibir = new DatagramPacket(bufferEntrada , bufferEntrada.length);
            cliente.socketA.setSoTimeout(100);
            try{
                cliente.socketA.receive(cliente.paqueteRecibir);
            }catch(SocketTimeoutException e){
                cliente.socketB.receive(cliente.paqueteRecibir);
            }
            cliente.mensajeRecibido = new String(cliente.paqueteRecibir.getData() , 0 , cliente.paqueteRecibir.getLength());

            if(cliente.mensajeRecibido.contains("Lluvia") || cliente.mensajeRecibido.contains("Viento") || cliente.mensajeRecibido.contains("Presión")){
                cliente.puertoA = cliente.paqueteRecibir.getPort();
                cliente.direccionServerA = cliente.paqueteRecibir.getAddress();
            }
            else{
                cliente.puertoB = cliente.paqueteRecibir.getPort();
                cliente.direccionServerB = cliente.paqueteRecibir.getAddress();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(cliente.mensajeRecibido);
    }

    protected void terminar(){
        this.running = false;
    }

    @Override
    public void run() {
        while(running){
            imprimirInformacion();
        }
    }
}
