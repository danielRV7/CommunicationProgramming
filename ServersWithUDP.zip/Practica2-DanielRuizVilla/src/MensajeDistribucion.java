package practica2;

public class MensajeDistribucion {

    private String texto;

    private String unidadLluvia;
    private String unidadViento;
    private String unidadPresion;
    private String unidadTemperatura;
    private String unidadHumedad;
    private String unidadRadiactividad;

    public MensajeDistribucion(char server) {
        establecerUnidades();
        crearMensaje(server);
    }

    public MensajeDistribucion(char server, String palabra) {
        establecerUnidades();
        cambiarUnidad(palabra);
        crearMensaje(server);
    }

    private void establecerUnidades(){
        this.unidadLluvia = "litros/m2";
        this.unidadViento = "km/h";
        this.unidadPresion = "mbar";
        this.unidadTemperatura = "ºC";
        this.unidadHumedad = "HR";
        this.unidadRadiactividad = "Bequerelio";
    }

    private void cambiarUnidad(String palabra){
        switch(palabra){
            case "lluvia":
                this.unidadLluvia = "litros/m3";
                break;
            case "viento":
                this.unidadViento = "metros/seg";
                break;
            case "presion":
                this.unidadPresion = "atm";
                break;
            case "temperatura":
                this.unidadTemperatura = "ºK";
                break;
            case "humedad":
                this.unidadHumedad = "%";
                break;
            case "radiactividad":
                this.unidadRadiactividad = "Curies";
                break;
        }
    }

    private void crearMensaje(char server){
        if(server=='A'){
            int lluvia = (int) (Math.random() * 100) + 1;
            int viento = (int) (Math.random() * 150) + 1;
            int presion = (int) (Math.random() * 1200) + 1;
            this.texto = "Lluvia : " + lluvia + " " + unidadLluvia + "\r\n"
                        + "Viento : " + viento + " " + unidadViento + "\r\n"
                        + "Presión : " + presion + " " + unidadPresion + "\r\n";
        }
        else if(server=='B'){
            int temperatura = (int) (Math.random() * 40) + 1;
            int humedad = (int) (Math.random() * 100) + 1;
            int radiactividad = (int) (Math.random() * 100) + 1;
            this.texto = "Temperatura : " + temperatura + " " + unidadTemperatura + "\r\n"
                        + "Humedad : " + humedad + " " + unidadHumedad + "\r\n"
                        + "Radiactividad : " + radiactividad + " " + unidadRadiactividad +  "\r\n";
        }
    }

    public String getTexto() {
        return texto;
    }

}
