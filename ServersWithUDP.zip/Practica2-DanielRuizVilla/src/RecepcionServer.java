package practica2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;

public class RecepcionServer extends Thread {

    private Server server;
    protected byte[] bufferEntrada = new byte[256];
    private boolean running=true;
    private String mensajeRecibido;
    private DatagramPacket paqueteRecibido;
    private DatagramPacket paqueteEnvio;

    public RecepcionServer(Server server){
        this.server = server;
    }

    public void comprobarRecepcion() {
            while(running){
                    try {
                        paqueteRecibido = new DatagramPacket(bufferEntrada , bufferEntrada.length);
                        server.socketServer.receive(paqueteRecibido);
                        mensajeRecibido = new String(paqueteRecibido.getData() , 0 , paqueteRecibido.getLength());
                        System.out.println("COMANDO RECIBIDO! " + mensajeRecibido + "\t Dirección: " + paqueteRecibido.getAddress());

                        if((mensajeRecibido.equals("CHRAIN")) || (mensajeRecibido.equals("CHWIND")) || (mensajeRecibido.equals("CHPRESS"))){
                            tratarMensaje(mensajeRecibido, paqueteRecibido.getAddress(), 9090);
                        }
                        else{
                            tratarMensaje(mensajeRecibido, paqueteRecibido.getAddress(), 9091);
                        }

                        if(paqueteEnvio!=null) {
                            server.socketServer.send(paqueteEnvio);
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
            }
    }

    public void construirMensaje(InetAddress direccionIP, int puerto, char server, String palabra){
        MensajeDistribucion mensaje = new MensajeDistribucion(server, palabra);
        String cadena = "SERVER " + server + " - Comando Recibido! CAMBIANDO UNIDAD - " + palabra + "\r\n\r\n";
        String texto = mensaje.getTexto();
        cadena += texto;
        byte[] array = cadena.getBytes();
        paqueteEnvio = new DatagramPacket(array , array.length , direccionIP , puerto);
    }

    public void tratarMensaje(String mensajeRecibido , InetAddress direccionIP , int puerto) {
        if(server.servidor=='A') {
            switch (mensajeRecibido) {
                case "CHRAIN":
                    construirMensaje(direccionIP, puerto, 'A', "lluvia");
                    break;
                case "CHWIND":
                    construirMensaje(direccionIP, puerto, 'A', "viento");
                    break;
                case "CHPRESS":
                    construirMensaje(direccionIP, puerto, 'A', "presion");
                    break;
                default:
                    paqueteEnvio = null;
            }
        }
        else if(server.servidor=='B'){
            switch(mensajeRecibido){
                case "CHTEMP":
                    construirMensaje(direccionIP, puerto, 'B', "temperatura");
                    break;
                case "CHHUM":
                    construirMensaje(direccionIP, puerto, 'B', "humedad");
                    break;
                case "CHRAD":
                    construirMensaje(direccionIP, puerto, 'B', "radiactividad");
                    break;
                default:
                    paqueteEnvio = null;
            }
        }
    }

    @Override
    public void run() {
        comprobarRecepcion();
    }
}
