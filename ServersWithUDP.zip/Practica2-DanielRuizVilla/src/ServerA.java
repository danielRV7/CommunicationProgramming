package practica2;

import java.io.IOException;
import java.net.*;

public class ServerA extends Server {

    public ServerA() {
        try {
            this.socketServer = new DatagramSocket();
            this.servidor = 'A';
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        ServerA server = new ServerA();
        boolean running = true;

        RecepcionServer recepcionServer = new RecepcionServer(server);
        recepcionServer.start();
        while (running) {
            MensajeDistribucion mensaje = new MensajeDistribucion('A');
            String texto = mensaje.getTexto();
            byte[] bytesTexto = texto.getBytes();
            try {
                InetAddress direccionBroadcast = getBroadcast();
                if(direccionBroadcast==null){
                    direccionBroadcast = InetAddress.getByName("localhost");
                }
                server.paqueteEnviar = new DatagramPacket(bytesTexto, bytesTexto.length, direccionBroadcast, 9090);
                server.socketServer.send(server.paqueteEnviar);
                Thread.sleep(5000);
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

