package practica2;

import java.io.IOException;
import java.net.*;

public class ServerB extends Server {

    public ServerB() {
        try {
            this.socketServer = new DatagramSocket();
            this.servidor = 'B';
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        ServerB server = new ServerB();
        boolean running = true;

        RecepcionServer recepcionServer = new RecepcionServer(server);
        recepcionServer.start();
        while (running) {
            MensajeDistribucion mensaje = new MensajeDistribucion('B');
            String texto = mensaje.getTexto();
            byte[] bytesTexto = texto.getBytes();
            try {
                InetAddress direccionBroadcast = getBroadcast();
                if (direccionBroadcast == null) {
                    direccionBroadcast = InetAddress.getByName("localhost");
                }
                server.paqueteEnviar = new DatagramPacket(bytesTexto , bytesTexto.length , direccionBroadcast , 9091);
                server.socketServer.send(server.paqueteEnviar);
                Thread.sleep(5000);
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
