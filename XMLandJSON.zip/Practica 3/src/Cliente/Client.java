package Cliente;

import Parsers.ParserJSON;
import Parsers.ParserXML;

import java.io.IOException;
import java.net.*;
import java.util.*;

public class Client {

    protected DatagramSocket socketA;
    protected DatagramSocket socketB;
    protected DatagramPacket paqueteEnviar;
    protected DatagramPacket paqueteRecibir;

    protected int puertoA;
    protected int puertoB;
    protected InetAddress direccionServerA;
    protected InetAddress direccionServerB;

    protected String comando;
    private Scanner entradaCliente;
    protected String mensajeRecibido;

    private ParserJSON parserJSON = new ParserJSON();
    private ParserXML parserXML = new ParserXML();

    private boolean json;
    private boolean xml;


    public Client() {
        try {
            this.puertoA = -1;
            this.puertoB = -1;
            this.entradaCliente = new Scanner(System.in);
            this.socketA = new DatagramSocket(9090);
            this.socketB = new DatagramSocket(9091);
            this.json = true;
            this.xml = false;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public synchronized void enviarComando(String comandoEnviar, int puertoServer, InetAddress direccionServer){
        String cadena;
        String comandoParseado;
        try {
            if(this.json){
                cadena = "JSON" + "=";
                comandoParseado = parserJSON.serializarControl(comandoEnviar);
            }
            else{
                cadena = "XML" + "=";
                comandoParseado = parserXML.serializarControl(comandoEnviar);
            }
            String mensajeCompleto = cadena + comandoParseado;
            byte[] envio = mensajeCompleto.getBytes();
            paqueteEnviar = new DatagramPacket(envio , envio.length, direccionServer, puertoServer);
            socketA.send(paqueteEnviar);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void ejecucion(Client cliente){
        ImpresionCliente impresion = new ImpresionCliente(cliente);
        impresion.start();
        do{
            comando = entradaCliente.nextLine();
            if(!comando.equals("STOP")){
                switch (comando) {
                    case "XML":
                        this.xml = true;
                        this.json = false;
                        cliente.enviarComando(comando , puertoA , direccionServerA);
                        cliente.enviarComando(comando , puertoB , direccionServerB);
                        break;
                    case "JSON":
                        this.xml = false;
                        this.json = true;
                        cliente.enviarComando(comando , puertoA , direccionServerA);
                        cliente.enviarComando(comando , puertoB , direccionServerB);
                        break;
                    case "CHRAIN":
                    case "CHWIND":
                    case "CHPRESS":
                        if (puertoA != -1) {
                            cliente.enviarComando(comando , puertoA , direccionServerA);
                        }
                        break;
                    case "CHTEMP":
                    case "CHHUM":
                    case "CHRAD":
                        if (puertoB != -1) {
                            cliente.enviarComando(comando , puertoB , direccionServerB);
                        }
                        break;
                }
            }
        }while(!cliente.comando.equals("STOP"));
        impresion.terminar();
        try {
            impresion.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        cliente.socketA.close();
        cliente.socketB.close();
    }

    public void ayudaComandos() {
        System.out.println("----------------- Comandos generales -----------------\r\n"
                + "\tSTART: Inicia la recepción.\r\n"
                + "\tSTOP: Interrumpe la recepción.\r\n"
                + "\tHELP: Muestra la ayuda.\r\n"
                + "\tJSON: Los envios y recepciones pasan a ser JSON (por defecto).\r\n"
                + "\tXML: Los envios y recepciones pasan a ser XML.\r\n"
                + "----------------- Comandos: Servidor A -----------------\r\n"
                + "\tCHRAIN: Cambia la unidad de medición de la lluvia.\r\n"
                + "\tCHWIND: Cambia la unidad de medición del viento.\r\n"
                + "\tCHPRESS: Cambia la unidad de medición de la presión.\r\n"
                + "----------------- Comandos: Servidor B -----------------\r\n"
                + "\tCHTEMP: Cambia la unidad de medición de la temperatura.\r\n"
                + "\tCHHUM: Cambia la unidad de medición de la humedad.\r\n"
                + "\tCHRAD: Cambia la unidad de medición de la radiactividad.\r\n"
                + "\r\n");
    }

    public static void main(String[] args) {
        Client cliente = new Client();
        cliente.ayudaComandos();
        System.out.println("NOTA: El primer comando introducido debe ser START.");
        cliente.comando = cliente.entradaCliente.nextLine();

        if (cliente.comando.equals("START")) {
            cliente.ejecucion(cliente);
        }
        else{
            do{
                System.out.println("Comando incorrecto. Introduzca START, por favor.");
                cliente.comando = cliente.entradaCliente.nextLine();
            }while(!cliente.comando.equals("START"));
            cliente.ejecucion(cliente);
        }
    }
}
