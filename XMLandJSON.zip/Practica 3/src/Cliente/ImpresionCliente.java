package Cliente;

import Parsers.*;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.SocketTimeoutException;
import Mensajes.Datos;

public class ImpresionCliente extends Thread{

    protected Client cliente;
    private byte[] bufferEntrada = new byte[65535];
    protected boolean running = true;
    protected boolean servidorTurno = true;
    ParserJSON parserJSON = new ParserJSON();
    ParserXML parserXML = new ParserXML();


    public ImpresionCliente(Client cliente) {
        this.cliente = cliente;
    }

    public synchronized void imprimirInformacion() {
        Datos datos = null;
        char servidor='A';
        String formato="";
        try {
            cliente.paqueteRecibir = new DatagramPacket(bufferEntrada , bufferEntrada.length);
            cliente.socketA.setSoTimeout(100);
            cliente.socketB.setSoTimeout(100);
            try{
                if(servidorTurno) {
                    servidor = 'A';
                    cliente.socketA.receive(cliente.paqueteRecibir);
                    cliente.puertoA = cliente.paqueteRecibir.getPort();
                    cliente.direccionServerA = cliente.paqueteRecibir.getAddress();
                }
                else{
                    servidor = 'B';
                    cliente.socketB.receive(cliente.paqueteRecibir);
                    cliente.puertoB = cliente.paqueteRecibir.getPort();
                    cliente.direccionServerB = cliente.paqueteRecibir.getAddress();
                }
                servidorTurno = !servidorTurno;

                cliente.mensajeRecibido = new String(cliente.paqueteRecibir.getData() , 0 , cliente.paqueteRecibir.getLength());
                String partes[] = cliente.mensajeRecibido.split("=",2);
                formato = partes[0];
                String mensaje = partes[1];

                if(formato.equals("JSON")){
                    datos = parserJSON.deserializar(mensaje);
                }
                else{
                    datos = parserXML.deserializar(mensaje);
                }

            }catch(SocketTimeoutException e){
                servidorTurno = !servidorTurno;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(datos!=null) {
            String texto = datos.imprimir(formato , servidor);
            System.out.println(texto);
        }
    }

    protected void terminar(){
        this.running = false;
    }

    @Override
    public void run() {
        while(running){
            imprimirInformacion();
        }
    }
}
