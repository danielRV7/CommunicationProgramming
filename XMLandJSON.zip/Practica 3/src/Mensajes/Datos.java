package Mensajes;

public class Datos {
    private String unidadLluvia=null;
    private String unidadViento=null;
    private String unidadPresion=null;
    private String unidadTemperatura=null;
    private String unidadHumedad=null;
    private String unidadRadiactividad=null;
    private Integer lluvia=null;
    private Integer viento=null;
    private Integer presion=null;
    private Integer temperatura=null;
    private Integer humedad=null;
    private Integer radiactividad=null;

    private String comando=null;

    public Datos() {
    }

    public String imprimir(String formato, char servidor) {
        if(servidor=='A'){
            return "Servidor: A - Formato: " + formato + "\r\n"
                    + "Lluvia = " + lluvia + " " + unidadLluvia + "\r\n"
                    + "Viento = " + viento + " " + unidadViento + "\r\n"
                    + "Presión = " + presion + " " + unidadPresion + "\r\n";
        }
        else{
            return "Servidor: B - Formato: " + formato + "\r\n"
                    + "Temperatura = " + temperatura + " " + unidadTemperatura + "\r\n"
                    + "Humedad = " + humedad + " " + unidadHumedad + "\r\n"
                    + "Radiactividad = " + radiactividad + " " + unidadRadiactividad + "\r\n";
        }
    }

    public String getUnidadLluvia() {
        return unidadLluvia;
    }

    public String getUnidadViento() {
        return unidadViento;
    }

    public String getUnidadPresion() {
        return unidadPresion;
    }

    public String getUnidadTemperatura() {
        return unidadTemperatura;
    }

    public String getUnidadHumedad() {
        return unidadHumedad;
    }

    public String getUnidadRadiactividad() {
        return unidadRadiactividad;
    }

    public Integer getLluvia() {
        return lluvia;
    }

    public Integer getViento() {
        return viento;
    }

    public Integer getPresion() {
        return presion;
    }

    public Integer getTemperatura() {
        return temperatura;
    }

    public Integer getHumedad() {
        return humedad;
    }

    public Integer getRadiactividad() {
        return radiactividad;
    }

    public String getComando() {
        return comando;
    }

    public void setUnidadLluvia(String unidadLluvia) {
        this.unidadLluvia = unidadLluvia;
    }

    public void setUnidadViento(String unidadViento) {
        this.unidadViento = unidadViento;
    }

    public void setUnidadPresion(String unidadPresion) {
        this.unidadPresion = unidadPresion;
    }

    public void setUnidadTemperatura(String unidadTemperatura) {
        this.unidadTemperatura = unidadTemperatura;
    }

    public void setUnidadHumedad(String unidadHumedad) {
        this.unidadHumedad = unidadHumedad;
    }

    public void setUnidadRadiactividad(String unidadRadiactividad) {
        this.unidadRadiactividad = unidadRadiactividad;
    }

    public void setLluvia(Integer lluvia) {
        this.lluvia = lluvia;
    }

    public void setViento(Integer viento) {
        this.viento = viento;
    }

    public void setPresion(Integer presion) {
        this.presion = presion;
    }

    public void setTemperatura(Integer temperatura) {
        this.temperatura = temperatura;
    }

    public void setHumedad(Integer humedad) {
        this.humedad = humedad;
    }

    public void setRadiactividad(Integer radiactividad) {
        this.radiactividad = radiactividad;
    }

    public void setComando(String comando) {
        this.comando = comando;
    }
}
