package Mensajes;

public class MensajeDistribucion {

    private static String unidadLluvia = "litros/m2";
    private static String unidadViento = "km/h";
    private static String unidadPresion = "mbar";
    private static String unidadTemperatura = "ºC";
    private static String unidadHumedad = "HR";
    private static String unidadRadiactividad = "Bequerelio";

    private static int idxUnidadLluvia = 0;
    private static int idxUnidadViento = 0;
    private static int idxUnidadPresion = 0;
    private static int idxUnidadTemperatura = 0;
    private static int idxUnidadHumedad = 0;
    private static int idxUnidadRadiactividad = 0;

    private static String arrayLluvia[] = {"litros/m2","litros/m3"};
    private static String arrayViento[] = {"km/h","metros/seg"};
    private static String arrayPresion[] = {"mbar","atm"};
    private static String arrayTemperatura[] = {"ºC","ºK"};
    private static String arrayHumedad[] = {"HR","%"};
    private static String arrayRadiactividad[] = {"Bequerelio","Curies"};

    private int lluvia;
    private int viento;
    private int presion;
    private int temperatura;
    private int humedad;
    private int radiactividad;

    public MensajeDistribucion(char server) {
        crearMensaje(server);
    }

    public MensajeDistribucion(char server, String palabra) {
        cambiarUnidad(palabra);
        crearMensaje(server);
    }

    private void cambiarUnidad(String palabra){
        switch(palabra){
            case "lluvia":
                idxUnidadLluvia = (idxUnidadLluvia+1) % 2;
                unidadLluvia = arrayLluvia[idxUnidadLluvia];
                break;
            case "viento":
                idxUnidadViento = (idxUnidadViento+1) % 2;
                unidadViento = arrayViento[idxUnidadViento];
                break;
            case "presion":
                idxUnidadPresion = (idxUnidadPresion+1) % 2;
                unidadPresion = arrayPresion[idxUnidadPresion];
                break;
            case "temperatura":
                idxUnidadTemperatura = (idxUnidadTemperatura+1) % 2;
                unidadTemperatura = arrayTemperatura[idxUnidadTemperatura];
                break;
            case "humedad":
                idxUnidadHumedad = (idxUnidadHumedad+1) % 2;
                unidadHumedad = arrayHumedad[idxUnidadHumedad];
                break;
            case "radiactividad":
                idxUnidadRadiactividad = (idxUnidadRadiactividad+1) % 2;
                unidadRadiactividad = arrayRadiactividad[idxUnidadRadiactividad];
                break;
        }
    }

    private void crearMensaje(char server){
        if(server=='A'){
            lluvia = (int) (Math.random() * 100) + 1;
            viento = (int) (Math.random() * 150) + 1;
            presion = (int) (Math.random() * 1200) + 1;
        }
        else if(server=='B'){
            temperatura = (int) (Math.random() * 40) + 1;
            humedad = (int) (Math.random() * 100) + 1;
            radiactividad = (int) (Math.random() * 100) + 1;
        }
    }

    public String getUnidadLluvia() {
        return unidadLluvia;
    }

    public String getUnidadViento() {
        return unidadViento;
    }

    public String getUnidadPresion() {
        return unidadPresion;
    }

    public String getUnidadTemperatura() {
        return unidadTemperatura;
    }

    public String getUnidadHumedad() {
        return unidadHumedad;
    }

    public String getUnidadRadiactividad() {
        return unidadRadiactividad;
    }

    public int getLluvia() {
        return lluvia;
    }

    public int getViento() {
        return viento;
    }

    public int getPresion() {
        return presion;
    }

    public int getTemperatura() {
        return temperatura;
    }

    public int getHumedad() {
        return humedad;
    }

    public int getRadiactividad() {
        return radiactividad;
    }

}
