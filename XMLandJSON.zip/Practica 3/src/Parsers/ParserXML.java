package Parsers;
import Mensajes.Datos;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class ParserXML implements Parser, ErrorHandler {

    @Override
    public String serializar(Datos datos) {
        String servidor;
        if (datos.getLluvia() != null) {
            servidor = "A";
        } else {
            servidor = "B";
        }
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder;
        Document doc = null;
        try {
            docBuilder = docFactory.newDocumentBuilder();
            doc = docBuilder.newDocument();

            if (servidor.equals("A")) {

                Element raiz = doc.createElementNS("http://www.danielruizvilla.com","A");
                raiz.setAttributeNS("http://www.w3.org/2001/XMLSchema-instance","xs:schemaLocation", "http://www.danielruizvilla.com EsquemaServerA.xsd");
                doc.appendChild(raiz);

                Element lluvia = doc.createElement("LLUVIA");
                raiz.appendChild(lluvia);
                Element valorLluvia = doc.createElement("VALOR");
                valorLluvia.appendChild(doc.createTextNode(datos.getLluvia().toString()));
                lluvia.appendChild(valorLluvia);
                Element unidadLluvia = doc.createElement("UNIDAD");
                unidadLluvia.appendChild(doc.createTextNode(datos.getUnidadLluvia()));
                lluvia.appendChild(unidadLluvia);

                Element viento = doc.createElement("VIENTO");
                raiz.appendChild(viento);
                Element valorViento = doc.createElement("VALOR");
                valorViento.appendChild(doc.createTextNode(datos.getViento().toString()));
                viento.appendChild(valorViento);
                Element unidadViento = doc.createElement("UNIDAD");
                unidadViento.appendChild(doc.createTextNode(datos.getUnidadViento()));
                viento.appendChild(unidadViento);

                Element presion = doc.createElement("PRESION");
                raiz.appendChild(presion);
                Element valorPresion = doc.createElement("VALOR");
                valorPresion.appendChild(doc.createTextNode(datos.getPresion().toString()));
                presion.appendChild(valorPresion);
                Element unidadPresion = doc.createElement("UNIDAD");
                unidadPresion.appendChild(doc.createTextNode(datos.getUnidadPresion()));
                presion.appendChild(unidadPresion);
            } else {

                Element raiz = doc.createElementNS("http://www.danielruizvilla.com","B");
                raiz.setAttributeNS("http://www.w3.org/2001/XMLSchema-instance","xs:schemaLocation", "http://www.danielruizvilla.com EsquemaServerB.xsd");
                doc.appendChild(raiz);

                Element temperatura = doc.createElement("TEMPERATURA");
                raiz.appendChild(temperatura);
                Element valorTemperatura = doc.createElement("VALOR");
                valorTemperatura.appendChild(doc.createTextNode(datos.getTemperatura().toString()));
                temperatura.appendChild(valorTemperatura);
                Element unidadTemperatura = doc.createElement("UNIDAD");
                unidadTemperatura.appendChild(doc.createTextNode(datos.getUnidadTemperatura()));
                temperatura.appendChild(unidadTemperatura);

                Element humedad = doc.createElement("HUMEDAD");
                raiz.appendChild(humedad);
                Element valorHumedad = doc.createElement("VALOR");
                valorHumedad.appendChild(doc.createTextNode(datos.getHumedad().toString()));
                humedad.appendChild(valorHumedad);
                Element unidadHumedad = doc.createElement("UNIDAD");
                unidadHumedad.appendChild(doc.createTextNode(datos.getUnidadTemperatura()));
                humedad.appendChild(unidadHumedad);

                Element radiactividad = doc.createElement("RADIACTIVIDAD");
                raiz.appendChild(radiactividad);
                Element valorRadiactividad = doc.createElement("VALOR");
                valorRadiactividad.appendChild(doc.createTextNode(datos.getRadiactividad().toString()));
                radiactividad.appendChild(valorRadiactividad);
                Element unidadRadiactividad = doc.createElement("UNIDAD");
                unidadRadiactividad.appendChild(doc.createTextNode(datos.getUnidadRadiactividad()));
                radiactividad.appendChild(unidadRadiactividad);
            }
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }

        StringWriter writer = null;
        try {
            DOMSource domSource = new DOMSource(doc);
            writer = new StringWriter();
            StreamResult result = new StreamResult(writer);
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer transformer = tf.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT , "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount" , "4");
            transformer.transform(domSource , result);
        } catch (TransformerException e) {
            e.printStackTrace();
        }
        try {
            String aux = writer.toString() + System.getProperty("line.separator");
            Files.write(Paths.get("XML/MensajesDistribucion.xml") , aux.getBytes() , StandardOpenOption.CREATE , StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.err.println("ERROR EN EL FICHERO: " + e.getMessage());
        }
        return writer.toString();
    }

    @Override
    public String serializarControl(String comando) {
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder;
        Document doc = null;
        try {
            docBuilder = docFactory.newDocumentBuilder();
            doc = docBuilder.newDocument();
            Element raiz = doc.createElementNS("http://www.danielruizvilla.com","CLIENTE");
            raiz.setAttributeNS("http://www.w3.org/2001/XMLSchema-instance","xs:schemaLocation", "http://www.danielruizvilla.com EsquemaControl.xsd");
            doc.appendChild(raiz);

            Element nodo = doc.createElement("COMANDO");
            raiz.appendChild(nodo);
            Element valor = doc.createElement("VALOR");
            valor.appendChild(doc.createTextNode(comando));
            nodo.appendChild(valor);

        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
        StringWriter writer = null;
        try {
            DOMSource domSource = new DOMSource(doc);
            writer = new StringWriter();
            StreamResult result = new StreamResult(writer);
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer transformer = tf.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT , "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount" , "4");
            transformer.transform(domSource , result);
        } catch (TransformerException e) {
            e.printStackTrace();
        }
        try {
            String aux = writer.toString() + System.getProperty("line.separator");
            Files.write(Paths.get("XML/MensajesControl.xml") , aux.getBytes() , StandardOpenOption.CREATE , StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.err.println("ERROR EN EL FICHERO: " + e.getMessage());
        }
        return writer.toString();
    }

    @Override
    public Datos deserializar(String xml) {
        Datos datos = new Datos();
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setAttribute("http://java.sun.com/xml/jaxp/properties/schemaLanguage", "http://www.w3.org/2001/XMLSchema");
        factory.setNamespaceAware(true);
        factory.setValidating(true);
        try {
            DocumentBuilder builder = factory.newDocumentBuilder();
            StringBuilder xmlStringBuilder = new StringBuilder();
            xmlStringBuilder.append(xml);
            ByteArrayInputStream input = new ByteArrayInputStream(xmlStringBuilder.toString().getBytes("UTF-8"));
            builder.setErrorHandler(this);
            Document doc = builder.parse(input);

            if(doc.getDocumentElement().getNodeName().equals("A")){
                NodeList nodes = doc.getElementsByTagName("VALOR");
                Element lluvia = (Element)nodes.item(0);
                Element viento = (Element)nodes.item(1);
                Element presion = (Element)nodes.item(2);
                int valorLluvia = Integer.parseInt(lluvia.getFirstChild().getTextContent());
                int valorViento = Integer.parseInt(viento.getFirstChild().getTextContent());
                int valorPresion = Integer.parseInt(presion.getFirstChild().getTextContent());
                datos.setLluvia(valorLluvia);
                datos.setViento(valorViento);
                datos.setPresion(valorPresion);

                NodeList nodesUnidades = doc.getElementsByTagName("UNIDAD");
                Element unidadLluvia = (Element)nodesUnidades.item(0);
                Element unidadViento = (Element)nodesUnidades.item(1);
                Element unidadPresion = (Element)nodesUnidades.item(2);
                datos.setUnidadLluvia(unidadLluvia.getFirstChild().getTextContent());
                datos.setUnidadViento(unidadViento.getFirstChild().getTextContent());
                datos.setUnidadPresion(unidadPresion.getFirstChild().getTextContent());
                return datos;
            }
            else{
                NodeList nodes = doc.getElementsByTagName("VALOR");
                Element temperatura = (Element)nodes.item(0);
                Element humedad = (Element)nodes.item(1);
                Element radiactividad = (Element)nodes.item(2);
                int valorTemperatura = Integer.parseInt(temperatura.getFirstChild().getTextContent());
                int valorHumedad = Integer.parseInt(humedad.getFirstChild().getTextContent());
                int valorRadiactividad = Integer.parseInt(radiactividad.getFirstChild().getTextContent());
                datos.setTemperatura(valorTemperatura);
                datos.setHumedad(valorHumedad);
                datos.setRadiactividad(valorRadiactividad);

                NodeList nodesUnidades = doc.getElementsByTagName("UNIDAD");
                Element unidadTemperatura = (Element)nodesUnidades.item(0);
                Element unidadHumedad = (Element)nodesUnidades.item(1);
                Element unidadRadiactividad = (Element)nodesUnidades.item(2);
                datos.setUnidadTemperatura(unidadTemperatura.getFirstChild().getTextContent());
                datos.setUnidadHumedad(unidadHumedad.getFirstChild().getTextContent());
                datos.setUnidadRadiactividad(unidadRadiactividad.getFirstChild().getTextContent());
                return datos;
            }
        } catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public String deserializarControl(String xml) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setAttribute("http://java.sun.com/xml/jaxp/properties/schemaLanguage", "http://www.w3.org/2001/XMLSchema");
        factory.setNamespaceAware(true);
        factory.setValidating(true);
        try {
            DocumentBuilder builder = factory.newDocumentBuilder();
            StringBuilder xmlStringBuilder = new StringBuilder();
            xmlStringBuilder.append(xml);
            ByteArrayInputStream input = new ByteArrayInputStream(xmlStringBuilder.toString().getBytes("UTF-8"));
            builder.setErrorHandler(this);
            Document doc = builder.parse(input);
            NodeList nodes = doc.getElementsByTagName("VALOR");
            Element node = (Element)nodes.item(0);
            return node.getFirstChild().getTextContent();
        } catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void warning(SAXParseException exception)
            throws SAXException {
        System.out.println("**Parsing Warning**\n" +
                "  Line:    " +
                exception.getLineNumber() + "\n" +
                "  URI:     " +
                exception.getSystemId() + "\n" +
                "  Message: " +
                exception.getMessage());
    }

    public void error(SAXParseException exception)
            throws SAXException {
        System.out.println("**Parsing Error**\n" +
                "  Line:    " +
                exception.getLineNumber() + "\n" +
                "  URI:     " +
                exception.getSystemId() + "\n" +
                "  Message: " +
                exception.getMessage());
        throw new SAXException("Error encountered");
    }

    public void fatalError(SAXParseException exception)
            throws SAXException {
        System.out.println("**Parsing Fatal Error**\n" +
                "  Line:    " +
                exception.getLineNumber() + "\n" +
                "  URI:     " +
                exception.getSystemId() + "\n" +
                "  Message: " +
                exception.getMessage());
        throw new SAXException("Fatal Error encountered");
    }
}