package Servers;

import Parsers.ParserJSON;
import Parsers.ParserXML;
import Mensajes.*;

import java.io.IOException;
import java.net.*;

public class ServerA extends Server {

    private ParserJSON parserJSON = new ParserJSON();
    private ParserXML parserXML = new ParserXML();

    public ServerA() {
        try {
            this.socketServer = new DatagramSocket();
            this.servidor = 'A';
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        ServerA server = new ServerA();
        boolean running = true;
        byte[] bytesTexto;

        RecepcionServer recepcionServer = new RecepcionServer(server);
        recepcionServer.start();
        while (running) {
            if(recepcionServer.isJson()){
                MensajeDistribucion mensaje = new MensajeDistribucion('A');
                Datos datos = new Datos();
                datos.setLluvia(mensaje.getLluvia());
                datos.setViento(mensaje.getViento());
                datos.setPresion(mensaje.getPresion());
                datos.setUnidadLluvia(mensaje.getUnidadLluvia());
                datos.setUnidadViento(mensaje.getUnidadViento());
                datos.setUnidadPresion(mensaje.getUnidadPresion());
                String json = server.parserJSON.serializar(datos);
                String mensajeJson = "JSON" + "=" + json;
                bytesTexto = mensajeJson.getBytes();
            }
            else{
                MensajeDistribucion mensaje = new MensajeDistribucion('A');
                Datos datos = new Datos();
                datos.setLluvia(mensaje.getLluvia());
                datos.setViento(mensaje.getViento());
                datos.setPresion(mensaje.getPresion());
                datos.setUnidadLluvia(mensaje.getUnidadLluvia());
                datos.setUnidadViento(mensaje.getUnidadViento());
                datos.setUnidadPresion(mensaje.getUnidadPresion());
                String xml = server.parserXML.serializar(datos);
                String mensajeXML = "XML" + "=" + xml;
                bytesTexto = mensajeXML.getBytes();
            }

            try {
                InetAddress direccionBroadcast = getBroadcast();
                if(direccionBroadcast==null){
                    direccionBroadcast = InetAddress.getByName("localhost");
                }
                server.paqueteEnviar = new DatagramPacket(bytesTexto, bytesTexto.length, direccionBroadcast, 9090);
                server.socketServer.send(server.paqueteEnviar);
                Thread.sleep(5000);
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

